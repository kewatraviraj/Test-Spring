/**
 * 
 */
package ne.test;

/**
 * @author Dell
 *
 */
public class Bob {

    private String jhon;

    public String getJhon() {
        return jhon;
    }

    public void setJhon(String jhon) {
        this.jhon = jhon;
    }

}