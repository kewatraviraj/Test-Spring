/**
 * 
 */
package ne.test1;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author Dell
 *
 */
@ComponentScan(basePackages="ne")
public class AppConfig {
	
}
