/**
 * 
 */
package demo.spring.test1;

/**
 * @author Dell
 *
 */
public class Teacher extends Movie {

}
