/**
 * 
 */
package demo.spring.test1;

/**
 * @author Dell
 *
 */
public class Student extends Movie {

}
